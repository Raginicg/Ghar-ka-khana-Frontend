package com.capgemini.exceptions;

public class NoSuchVendorException extends Exception {
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	public NoSuchVendorException(String message) {
		super(message);
	}
}
