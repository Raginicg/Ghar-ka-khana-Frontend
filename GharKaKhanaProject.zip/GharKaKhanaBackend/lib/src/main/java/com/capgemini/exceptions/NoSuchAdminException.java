package com.capgemini.exceptions;

public class NoSuchAdminException extends Exception {
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	public NoSuchAdminException(String message) {
		super(message);
	}
}
