1. Create react project using
    npx create-react-app react-student-frontend
2. Install required dependencies
    npm install axios --save
    npm install react-router-dom --save
    npm install redux --save
    npm install react-redux --save
    npm install redux-devtools-extension --save
    npm install redux-logger --save
    npm install redux-thunk --save
    npm i @material-ui/core
    npm install @material-ui/icons
    npm install react-numeric-input
3. Run back end java application
4. Run app using
    npm start