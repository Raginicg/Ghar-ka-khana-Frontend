import React, { Component } from 'react'
import { Button, Grid, Paper } from '@material-ui/core'
import { TextField, IconButton, InputAdornment } from '@material-ui/core'
import { VendorService } from '../../Services/VendorService'
import { Vendor } from '../../Model/Vendor'
import PersonIcon from '@material-ui/icons/Person';
import LockIcon from '@material-ui/icons/Lock';
import Visibility from '@material-ui/icons/Visibility';
import VisibilityOff from '@material-ui/icons/VisibilityOff';
import axios from 'axios'

export default class LoginVendor extends Component {
    state = { //defining state
        loginvendor: new Vendor(),
        showPassword: false,
        error: {
            userNameError: "",
            passwordError: "",
            invalidCredentials: ""
        }
    }

    handleClickShowPassword = () => {
        this.setState({ ...this.state, showPassword: !this.state.showPassword });
    };

    handleMouseDownPassword = (event) => {
        event.preventDefault();
    };

    validate = () => { //cehcking for validation
        let flag = true;
        let error = {};
        if (!this.state.loginvendor.vendorUsername) {
            flag = false;
            error.userNameError = "Username Is Required";
        }
        if (!this.state.loginvendor.vendorPassword) {
            flag = false;
            error.passwordError = "Password Is Required";
        }

        this.setState({ error: error })
        return flag;
    };
    handleSubmit = async (event) => { //creating method for onsubmit event
        event.preventDefault();

        let isValid = this.validate();
        if (!isValid) { //checking validation is proper or not
            return false;
        }

        let service = new VendorService()
        service.loginVendor(this.state.loginvendor.vendorUsername, this.state.loginvendor.vendorPassword) // calling loginVendor from service and providing two parameters
            .then((result) => {
                if (result.data != null) { //checking if result is null 
                    sessionStorage.setItem("vendor", this.state.loginvendor.vendorUsername)

                    axios.get(`http://localhost:9090/GharKaKhana-api/admins/viewAllVendor/`) // getting all the vendors using axios and particular url of the controller
                        .then((result) => {

                            let arr = result.data;
                            for (var i = 0; i < arr.length; i++) {
                                console.log(arr[i].vendorUsername)
                                if (arr[i].vendorUsername == this.state.loginvendor.vendorUsername) {
                                    console.log(arr[i].vendorId)
                                    localStorage.setItem("venId", arr[i].vendorId)
                                }
                            }

                        })
                        .catch((error) => {
                            alert(error)
                        });
                    this.props.history.push("/vendordashboard"); //pushing to vendor dashboard if credentials are valid
                } else {
                    this.setState({ error: { invalidCredentials: "Invalid Credentials" } })
                }
            })
            .catch((error) => {
                this.setState({ error: { invalidCredentials: "Invalid Credentials" } })
            });
    };

    render() {
        const bgStyle = { zIndex: -1, position: "absolute", height: "100vh", width: "98.5vw", backgroundImage: "linear-gradient(65deg, #fea82f, #fcecdd)" }
        const paperStyle = { padding: 20, height: '70vh', width: 330, margin: "25px auto" }
        return (
            <>
                <div style={bgStyle} className="style">
                </div>
                <Grid>
                    <Paper elevation={10} style={paperStyle}>
                        <div className="container">
                            {/* calling handleSubmit method for unsubmit */}
                            <form onSubmit={this.handleSubmit}> 
                                <h2 className="text-center">Sign In</h2>
                                <div className="mt-5">
                                    <TextField id="username" label="Enter Username" variant="outlined" fullWidth
                                        InputProps={{
                                            startAdornment: (
                                                <InputAdornment position="start">
                                                    <PersonIcon />
                                                </InputAdornment>
                                            ),
                                        }}
                                        value={this.state.loginvendor.vendorUsername} //getting value from state
                                        onChange={
                                            (e) => {
                                                //setting the state
                                                this.setState({ loginvendor: { ...this.state.loginvendor, vendorUsername: e.target.value.replace(/[^a-zA-Z]/ig, '') } })
                                            }
                                        }
                                    />
                                    <div style={{ color: "red" }}>{this.state.error.userNameError}</div>
                                </div>

                                <div className="mt-5">
                                    <TextField id="password" label="Enter Password" variant="outlined" fullWidth
                                        InputProps={{
                                            startAdornment: (
                                                <InputAdornment position="start">
                                                    <LockIcon />
                                                </InputAdornment>
                                            ),
                                            endAdornment: (
                                                <InputAdornment position="end">
                                                    <IconButton
                                                        aria-label="toggle password visibility"
                                                        onClick={this.handleClickShowPassword}
                                                        onMouseDown={this.handleMouseDownPassword}
                                                        edge="end"
                                                    >
                                                        {this.state.showPassword ? <Visibility /> : <VisibilityOff />}
                                                    </IconButton>
                                                </InputAdornment>
                                            ),
                                        }}
                                        type={this.state.showPassword ? "text" : "password"}
                                        value={this.state.loginvendor.vendorPassword} //getting value from state
                                        onChange={(e) =>
                                            //setting state
                                            this.setState({ loginvendor: { ...this.state.loginvendor, vendorPassword: e.target.value } })
                                        }
                                    />
                                    {/* giving alert if password field is blank */}
                                    <div style={{ color: "red" }}>{this.state.error.passwordError}</div> 
                                </div> 
                                {/* giving alert if invalid credentials are provided */}
                                <div style={{ color: "red" }}>{this.state.error.invalidCredentials}</div> 
                                <div className="mt-5 text-center">
                                    <Button variant="contained" color="primary" type="submit">
                                        LOGIN
                                </Button>
                                </div>
                            </form>
                        </div>
                    </Paper>
                </Grid>
            </>
        )
    }
}