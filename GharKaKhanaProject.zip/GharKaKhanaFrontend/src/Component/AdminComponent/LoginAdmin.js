import React, { Component } from 'react'
import { Button, Grid, Paper, TextField, IconButton, InputAdornment } from '@material-ui/core'
import { AdminService } from '../../Services/AdminService'
import { Admin } from '../../Model/Admin'
import PersonIcon from '@material-ui/icons/Person'
import LockIcon from '@material-ui/icons/Lock'
import Visibility from '@material-ui/icons/Visibility'
import VisibilityOff from '@material-ui/icons/VisibilityOff'

export default class LoginAdmin extends Component {
    state = {
        loginadmin: new Admin(),
        showPassword: false,
        error: {
            userNameError: "",
            passwordError: "",
            invalidCredentials: ""
        }
    }

    handleClickShowPassword = () => {
        this.setState({ ...this.state, showPassword: !this.state.showPassword });
    };

    handleMouseDownPassword = (event) => {
        event.preventDefault();
    };

    validate = () => {
        let flag = true;
        let error = {};
        if (!this.state.loginadmin.adminUsername) {
            flag = false;
            error.userNameError = "User Name Is Required";
        }
        if (!this.state.loginadmin.adminPassword) {
            flag = false;
            error.passwordError = "Password Is Required";
        }

        this.setState({ error: error })
        return flag;
    };
    handleSubmit = async (event) => {
        event.preventDefault();

        let isValid = this.validate();
        if (!isValid) {
            return false;
        }

        let service = new AdminService();
        service.adminLogin(this.state.loginadmin.adminUsername, this.state.loginadmin.adminPassword)
            .then((result) => {
                if (result.data != null) {
                    sessionStorage.setItem("admin", this.state.loginadmin.adminUsername)
                    this.props.history.push("/admindashboard");
                } else {
                    this.setState({ error: { invalidCredentials: "Invalid Credentials" } })
                }
            })
            .catch((error) => {
                this.setState({ error: { invalidCredentials: "Invalid Credentials" } })
            });
    };

    render() {
        const bgStyle = { zIndex: -1, position: "absolute", height: "100vh", width: "98.5vw", backgroundImage: "linear-gradient(65deg, #fea82f, #fcecdd)" }
        const paperStyle = { padding: 20, height: '70vh', width: 330, margin: "25px auto" }
        return (
            <>
                <div style={bgStyle} className="style">
                </div>
                <Grid>
                    <Paper elevation={10} style={paperStyle}>
                        <div>
                            <form onSubmit={this.handleSubmit}>
                                <h2 className="text-center">Sign In</h2>
                                <div className="mt-5">
                                    <TextField id="username" label="Enter Username" variant="outlined" fullWidth
                                        InputProps={{
                                            'data-testid':'userName',
                                            startAdornment: (
                                                <InputAdornment position="start">
                                                    <PersonIcon />
                                                </InputAdornment>
                                            ),
                                        }}
                                        value={this.state.loginadmin.adminUsername}
                                        onChange={(e) =>
                                            this.setState({ loginadmin: { ...this.state.loginadmin, adminUsername: e.target.value.replace(/[^a-zA-Z]/ig, '') } })
                                        }
                                    />
                                    <div style={{ color: "red" }}>{this.state.error.userNameError}</div>
                                </div>

                                <div className="mt-5">
                                    <TextField id="password" label="Enter Password" variant="outlined" fullWidth
                                        InputProps={{
                                            'data-testid':'password',
                                            startAdornment: (
                                                <InputAdornment position="start">
                                                    <LockIcon />
                                                </InputAdornment>
                                            ),
                                            endAdornment: (
                                                <InputAdornment position="end">
                                                    <IconButton
                                                        aria-label="toggle password visibility"
                                                        onClick={this.handleClickShowPassword}
                                                        onMouseDown={this.handleMouseDownPassword}
                                                        edge="end"
                                                    >
                                                        {this.state.showPassword ? <Visibility /> : <VisibilityOff />}
                                                    </IconButton>
                                                </InputAdornment>
                                            ),
                                        }}
                                        type={this.state.showPassword ? "text" : "password"}
                                        value={this.state.loginadmin.adminPassword}
                                        onChange={(e) =>
                                            this.setState({ loginadmin: { ...this.state.loginadmin, adminPassword: e.target.value } })
                                        }
                                    />
                                    <div style={{ color: "red" }}>{this.state.error.passwordError}</div>
                                </div>
                                <div style={{ color: "red" }}>{this.state.error.invalidCredentials}</div>
                                <div className="mt-5 text-center">
                                    <Button variant="contained" color="primary" type="submit">
                                        LOGIN
                                </Button>
                                </div>
                            </form>
                        </div>
                    </Paper>
                </Grid>
            </>
        )
    }
}