import React, { Component } from 'react'
// import React because the render() method is used to convert JSX to dom elements
import { Button, Grid, Paper } from '@material-ui/core'
import { Customer } from '../../Model/Customer';
import { CustomerService } from '../../Services/CustomerService'
import { IconButton, InputAdornment, TextField } from '@material-ui/core'
import PersonIcon from '@material-ui/icons/Person'
import AccountBoxIcon from '@material-ui/icons/AccountBox';
import LockIcon from '@material-ui/icons/Lock'
import PhoneIcon from '@material-ui/icons/Phone';
import EmailIcon from '@material-ui/icons/Email';
import FiberPinIcon from '@material-ui/icons/FiberPin';
import RoomIcon from '@material-ui/icons/Room';
import LocationCityIcon from '@material-ui/icons/LocationCity';
import HomeIcon from '@material-ui/icons/Home';
import Visibility from '@material-ui/icons/Visibility';
import VisibilityOff from '@material-ui/icons/VisibilityOff';
import { Link } from 'react-router-dom';

// Extending a Component allows us to pass props to a user defined class 
// when a constructor is not present like it is in the App class.
export default class RegisterCustomer extends Component {
    service = new CustomerService();
    state = {
        // The state object is where you store property
        // values that belongs to the component
        customer: new Customer(),
        showPassword: false,
        error: {
            firstnameError: "",
            lastnameError: "",
            contactNoError: "",
            emailidError: "",
            passwordError: "",
            userNameError: "",
            areaError: "",
            cityError: "",
            pincodeError: "",
            stateError: ""
        }
    }

    handleClickShowPassword = () => {
        this.setState({ ...this.state, showPassword: !this.state.showPassword });
    };

    handleMouseDownPassword = (event) => {
        event.preventDefault();
    };
// Used for validation of the customer login
    validate = () => {
        let flag = true;
        let error = {};
        if (!this.state.customer.firstName) {
            flag = false;
            error.firstnameError = "First Name Is Required";
        }
        if (!this.state.customer.lastName) {
            flag = false;
            error.lastnameError = "Last Name Is Required";
        }

        if (!this.state.customer.contactNo) {
            flag = false;
            error.contactNoError = "Contact Number Is Required";
        }

        if (!this.state.customer.userName) {
            flag = false;
            error.userNameError = "Username Is Required";
        }

        if (!this.state.customer.password) {
            flag = false;
            error.passwordError = "Password Is Required";
        }
        if (!this.state.customer.emailId) {
            flag = false;
            error.emailidError = "Email Is Required";
        }

        if (!this.state.customer.customerAddress.city) {
            flag = false;
            error.cityError = "City Is Required";
        }

        if (!this.state.customer.customerAddress.area) {
            flag = false;
            error.areaError = "Area Is Required";
        }

        if (!this.state.customer.customerAddress.pincode) {
            flag = false;
            error.pincodeError = "Pincode Is Required";
        }
        if (!this.state.customer.customerAddress.state) {
            flag = false;
            error.stateError = "State Is Required";
        }

        this.setState({ error: error })
        return flag;
    };

    handleSubmit = async (event) => {
        event.preventDefault();

        let isValid = this.validate();
        if (!isValid) {
            return false;
        }
        this.service.registerCustomer(this.state.customer)
        // Customer register method is been called from 
        // CustomerService
            .then((data) => {
                alert("Registered Successfully.");
                this.props.history.push("/customerlogin");
            })
            .catch((error) => {
                alert("Registration failed")
                this.props.history.push("/register");
            });
    };
// the component is able to render whatever is returned from the render prop
    render() {
        const bgStyle = { zIndex: -1, position: "absolute", height: "186vh", width: "98.5vw", backgroundImage: "linear-gradient(65deg, #fea82f, #fcecdd)" }
        const paperStyle = { padding: 20, height: 'auto', width: 340, margin: "25px auto" }
        return (
            <>
                <div style={bgStyle} className="style">
                </div>
                <Grid>
                    <Paper elevation={10} style={paperStyle}>
                        <div className="container">

                            <form onSubmit={this.handleSubmit}>
                                <h2 className="text-center">Registeration</h2>
                                <div className="mt-5">
                                    <TextField id="fname" label="Enter First Name" variant="outlined" fullWidth
                                        InputProps={{
                                            // Inputprops: Extends the native input props
                                            startAdornment: (
                                                <InputAdornment position="start">
                                                    <PersonIcon />
                                                </InputAdornment>
                                            ),
                                        }}
                                        value={this.state.customer.firstName}
                                        onChange={(e) =>
                                            this.setState({ customer: { ...this.state.customer, firstName: e.target.value.replace(/[^a-zA-Z]/ig, '') } })
                                        } />
                                    <div style={{ color: "red" }}>{this.state.error.firstnameError}</div>
                                </div>


                                <div className="mt-4">
                                    <TextField id="lname" label="Enter Last Name" variant="outlined" fullWidth
                                        InputProps={{
                                            startAdornment: (
                                                <InputAdornment position="start">
                                                    {/* The component used for the root node */}
                                                    <PersonIcon />
                                                </InputAdornment>
                                            ),
                                        }}
                                        value={this.state.customer.lastName}
                                        onChange={(e) =>
                                            this.setState({ customer: { ...this.state.customer, lastName: e.target.value.replace(/[^a-zA-Z]/ig, '') } })
                                        }
                                    />
                                    <div style={{ color: "red" }}>{this.state.error.lastnameError}</div>
                                </div>


                                <div className="mt-4">
                                    <TextField id="contact" label="Enter Contact" variant="outlined" fullWidth type="number"
                                        InputProps={{
                                            startAdornment: (
                                                <InputAdornment position="start">
                                                    <PhoneIcon />
                                                </InputAdornment>
                                            ),
                                        }}
                                        value={this.state.customer.contactNo}
                                        onChange={(e) =>
                                            this.setState({ customer: { ...this.state.customer, contactNo: e.target.value.replace(/^[0-9]{11,11}$/g, '') } })
                                        }
                                    />
                                    <div style={{ color: "red" }}>{this.state.error.contactNoError}</div>
                                </div>

                                <div className="mt-4">
                                    <TextField id="email" label="Enter Email" variant="outlined" fullWidth
                                        InputProps={{
                                            startAdornment: (
                                                <InputAdornment position="start">
                                                    <EmailIcon />
                                                </InputAdornment>
                                            ),
                                        }}
                                        value={this.state.customer.emailId}
                                        onChange={(e) =>
                                            this.setState({ customer: { ...this.state.customer, emailId: e.target.value } })
                                        }
                                    />
                                    <div style={{ color: "red" }}>{this.state.error.emailidError}</div>
                                </div>

                                <div className="mt-4">
                                    <TextField id="username" label="Enter Username" variant="outlined" fullWidth
                                        InputProps={{
                                            startAdornment: (
                                                <InputAdornment position="start">
                                                    <AccountBoxIcon />
                                                </InputAdornment>
                                            ),
                                        }}
                                        value={this.state.customer.userName}
                                        onChange={(e) =>
                                            this.setState({ customer: { ...this.state.customer, userName: e.target.value.replace(/[^a-zA-Z]/ig, '') } })
                                        }
                                    />
                                    <div style={{ color: "red" }}>{this.state.error.userNameError}</div>
                                </div>

                                <div className="mt-4">
                                    <TextField id="password" label="Enter Password" variant="outlined" fullWidth
                                        InputProps={{
                                            startAdornment: (
                                                <InputAdornment position="start">
                                                    <LockIcon />
                                                </InputAdornment>
                                            ),
                                            endAdornment: (
                                                <InputAdornment position="end">
                                                    <IconButton
                                                        aria-label="toggle password visibility"
                                                        onClick={this.handleClickShowPassword}
                                                        onMouseDown={this.handleMouseDownPassword}
                                                        edge="end"
                                                    >
                                                        {this.state.showPassword ? <Visibility /> : <VisibilityOff />}
                                                    </IconButton>
                                                </InputAdornment>
                                            ),
                                        }}
                                        type={this.state.showPassword ? "text" : "password"}
                                        value={this.state.customer.password}
                                        onChange={(e) =>
                                            this.setState({ customer: { ...this.state.customer, password: e.target.value } })
                                        }
                                    />
                                    <div style={{ color: "red" }}>{this.state.error.passwordError}</div>
                                </div>

                                <div className="mt-4">
                                    <TextField id="area" label="Enter Area" variant="outlined" fullWidth
                                        InputProps={{
                                            startAdornment: (
                                                <InputAdornment position="start">
                                                    <HomeIcon />
                                                </InputAdornment>
                                            ),
                                        }}
                                        value={this.state.customer.customerAddress.area}
                                        onChange={(e) =>
                                            this.setState({ customer: { ...this.state.customer, customerAddress: { ...this.state.customer.customerAddress, area: e.target.value.replace(/[^a-zA-Z]/ig, '') } } })
                                        }
                                    />
                                    <div style={{ color: "red" }}>{this.state.error.areaError}</div>
                                </div>

                                <div className="mt-4">
                                    <TextField id="city" label="Enter City" variant="outlined" fullWidth
                                        InputProps={{
                                            startAdornment: (
                                                <InputAdornment position="start">
                                                    <LocationCityIcon />
                                                </InputAdornment>
                                            ),
                                        }}
                                        value={this.state.customer.customerAddress.city}
                                        onChange={(e) =>
                                            this.setState({ customer: { ...this.state.customer, customerAddress: { ...this.state.customer.customerAddress, city: e.target.value.replace(/[^a-zA-Z]/ig, '') } } })
                                        }
                                    />
                                    <div style={{ color: "red" }}>{this.state.error.cityError}</div>
                                </div>

                                <div className="mt-4">
                                    <TextField id="pincode" label="Enter Pincode" variant="outlined" fullWidth type="number" maxlength="6"
                                        InputProps={{
                                            startAdornment: (
                                                <InputAdornment position="start">
                                                    <FiberPinIcon />
                                                </InputAdornment>
                                            ),
                                        }}
                                        value={this.state.customer.customerAddress.pincode}
                                        onChange={(e) =>
                                            this.setState({ customer: { ...this.state.customer, customerAddress: { ...this.state.customer.customerAddress, pincode: e.target.value.replace(/^[0-9]{7,7}$/g, '') } } })
                                        }
                                    />
                                    <div style={{ color: "red" }}>{this.state.error.pincodeError}</div>
                                </div>
                                <div className="mt-4">
                                    <TextField id="state" label="Enter State" variant="outlined" fullWidth
                                        InputProps={{
                                            startAdornment: (
                                                <InputAdornment position="start">
                                                    <RoomIcon />
                                                </InputAdornment>
                                            ),
                                        }}
                                        value={this.state.customer.customerAddress.state}
                                        onChange={(e) =>
                                            this.setState({ customer: { ...this.state.customer, customerAddress: { ...this.state.customer.customerAddress, state: e.target.value.replace(/[^a-zA-Z]/ig, '') } } })
                                        }
                                    />
                                    <div style={{ color: "red" }}>{this.state.error.stateError}</div>
                                </div>

                                <div className="mt-4 text-center">
                                    <Button variant="contained" color="primary" type="submit">REGISTER</Button>
                                    <br/>
                                    <div className="mt-3 text-center">
                                    <Link to="/customerlogin">Already a User?</Link>
                                    </div>
                                </div>
                            </form>
                        </div >
                    </Paper>
                </Grid>
            </>
        )
    }
}