import { Vendor } from "./Vendor";

export class FoodItem{
    foodId="";
    foodName="";
    foodPrice="";
    foodQuantity="";
    vendor=new Vendor();
}