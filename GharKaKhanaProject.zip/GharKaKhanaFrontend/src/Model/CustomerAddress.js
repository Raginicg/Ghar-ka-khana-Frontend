// Customer Address class created
export class CustomerAddress{
    addressId="";
    city="";
    area="";
    state="";
    pincode="";
}