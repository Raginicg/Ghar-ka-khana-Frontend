// Model class created of Admin and exported directly
export class Admin{
    // Admin Related entity
    adminId="";
    adminName="";
    adminUsername=""; 
    adminPassword="";  
}