// VendorAddress class created
export class VendorAddress {
    vendorAddressId = "";
    vendorCity = "";
    area = "";
    vendorState = "";
    vendorPincode = "";
}